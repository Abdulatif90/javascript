/*naming standarts: Camel, Snake, Kebab, Pascal case*/

/*Camel case*/  

// const yourName= " Ali";
// function isPerson (){
//   return true;
// }

/*Snake case*/

// const your_name= "Ali";
// function is_person(){
//   return true;
// }

/*Kebab case : your-name.js*/

/*Pascal case : class = > PersonGroup*/

/*class larni yaratish*/

// const person1 = {
//   name="Ali",
//   age=30
// }

// const person2 = {
//   name="Nodir",
//   age=35
// }

// const person3 = {
//   name="Nosir",
//   age=23
// }

// class orqali bir nechta object yaratish

// class Person {
//   // state
  
//   // constructor
//   constructor(name,age){
//     this.name=name,
//     this.age=age
//   }
  
//   // method
//   greetings(){
//     console.log(`my name is ${this.name} and my age is ${this.age}`)
//   }
//   introduce() {
//     console.log(`Hi. how are you , ${this.name}!!!`)
//   }
// }

// const person1 = new Person('Ali',30);
// const person2 = new Person('Vali',35);
// const person3 = new Person('Bali',40);

// person1.greetings();
// person1.introduce();

// person2.greetings();
// person2.introduce();

// person3.greetings();
// person3.introduce();


//  static methodlar


// class Person {
//   // state
//   static serialNumber = 40;  
//   // constructor
//   constructor(name,age){
//     this.name=name,
//     this.age=age
//   }
  
//   // method
//   greetings(){
//     console.log(`my name is ${this.name} and my age is ${this.age}`)
//   }
//   introduce() {
//     console.log(`Hi. how are you , ${this.name}!!!`)
//   }
//   static help (){
//     console.log('hi, welcome to coding environment, Ali!!!')
//   }
// }

// const person1 = new Person('Ali',30);
//   /*person1.help();  - bunda bu ishga tushmaydi.*/
// Person.help(); /* bu static methidlar class larning parentlari orqali ishga tushiriladi*/
// const number1=Person.serialNumber; /*bu function bo`lmagani uchun serailNumberdan kn () qo`yilmaydi*/
// console.log(number1);

