/*programming paradigm keng qo`llaniladiganlari:
1.Functional Programming (FP) (Funksional dasturlash)
2. Object-Oriented Programming (OOP) (Ob'ektga yo'naltirilgan dasturlash):
  - Encapsulation (Inkapsulyatsiya): Ma'lumotlar va metodlar bir ob'ektda birlashtiriladi.
  - Inheritance (Merosi): Klasslar boshqa klasslardan meros oladi.
  - Polymorphism (Polimorfizm): Bir xil nomdagi metodlar turli ob'ektlar uchun ishlaydi.
  - Abstraction (Abstraktsiya): Foydalanuvchidan ichki ishlovlarni yashirish.*/

/*Object built via literal method*/

// const programmer ={
//   name: "Abdulatif",
//   age: 34,
//   nationality: "Uzbek",
//   location:"Busan",
//   greetings(){
//     console.log("Hi everbody from Abdulatif!!!");
//   },
//   introduce() {
//     console.log(`I am ${this.name} and my age is ${this.age}`); /* bunda Esc ostidagi teskari bir tirnoq ishlatiladi shunda ishlaydi*/
//   }
// };


// const person =programmer.name; /* bunda programmer functiondagi name key ni chaqirib olish*/
// console.log("name:", person) /*bu shu keyni consolega chiqarish*/
// programmer.greetings(); /* programmer function ichidagi greetings 'key' ni value sini consolega chiqarish*/
// programmer.introduce(); /* programmer function ichidagi introduce 'key' ni value sini consolega chiqarish*/ 

/*keyingi step - Dom dan kereli attributelarni property larini chaqirib olish
bu getElementById bu Id lar orqali Domdan ularni chaqirib olish yani button yozuvini ham o`zgartirishda foydalanish mumkin
Bu addEventListener da alert orqali tinglovchiga habar yetkazish mumkin*/

// const butt=document.getElementById("button"); 
// console.log(butt);

// butt.addEventListener('click', function() { 
//   alert('you pressed the button');
// }); 


/* primitive and Object variables
-string - bu berilgan qiymat- matnni ifodalaydi
-Number - son ko`rinishini ifodalaydi
-booleen - true va false qiymatlarini qabul qiladi
Null- bu qiyumat berilmaganda */

/*primitivelarda no preference but value */

// const a= "Abdulatif";
// const b= 35;
// const c= true;
// // const d= Null;

// let x = a 
// x="Ali";
// console.log(a); /*bu primitive lar faqat qiymatga ega bo`lgani uchun ular o`zgarmaydi*/

/*Objectlarni key va value bo`ladi */

// const client ={
//   name:"Ann",
//   age:25
// }

// const client1=client; /*bunda client qiymatlari shuncahaki client1 ga yuklatilgan*/
// client1.name="Barbara"; /*clinet1 name boshqa value  olsa client.name value si ham shunchaki o`zgaradi*/ 
// console.log("the first client`s name:", client.name); 
// console.log("the second client`s name:", client1.name);

// client.name="Jwnifer" /* bunda clint1 yoki client name value si o`zgarishi ikkalasiga ham teng tasir qiladi. chunki client1=client.name ga teng */
// console.log("the first client`s name:", client.name); 
// console.log("the second client`s name:", client1.name);

/*spread operatori - avvalgi object malumotlaridan foydalanib yangi object yaratish*/

// const client ={
//   name:"Ann",
//   age:25
// }

// const client1= {...client};
// client1.name="Jenifer";
// console.log(client1.name);
// console.log(client.name); 

/*Objectlarni consturction orqali yaratish*/

// const programmer=new Object();
// programmer.name="Abdulatif";
// programmer.age=34;
// programmer.hobby="football";

// console.log(`my name is ${programmer.name} and my age is ${programmer.age} and also I am fond of ${programmer.hobby}`);

// const keys = Object.keys(programmer);
// const values= Object.values(programmer);
// console.log(keys);  /*keys va values larinin console ga chiqarish*/
// console.log(values);


